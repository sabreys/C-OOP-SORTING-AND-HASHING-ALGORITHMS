#ifndef __COUNTING_H__
#define __COUNTING_H__

#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#define RANGE 255 //char değerler için max aralık

/* Counting Sort Kütüphanesi
* Counting Sort  Zaman karmaşıklığı sorununu çözmek için geliştirilmiş bir sıralama algoritmasıdır.
* Bu kütüphane char, int ,long int , unsigned int, short int, long long int ve özel structlar üzerinde  çalışabilmektedir.
* Programlamada Ozel Konular Dersi 
*/

// counting sort makrosu. uygun tipteki fonksiyonlara yönlendirir.
#define countingSort(X, Y) _Generic((X), \
  char *: countingSortCHAR, \
  int *: countingSortINT, \
  long int *: countingSortLONGINT, \
  unsigned int *: countingSortUNSIGNEDINT, \
  short int *: countingSortSHORTINT, \
  long long int *: countingSortLONGLONGINT, \
  CustomModel *: countingSortCUSTOM, \
  default: errorMessage)((X), (Y))

// count dizisinin üst aralığını bulmak için çalışan fonksiyon. en büyük elemanı bulur
#define findRange(X, Y) _Generic((X), \
  char *: returnCharRange, \
  int *: findRangeINT, \
  unsigned int *: findRangeUNSIGNEDINT, \
  short int *: findRangeSHORTINT, \
  long int *: findRangeLONGINT, \
  long long int *: findRangeLONGLONGINT, \
  CustomModel *: findRangeCUSTOM, \
  default: errorMessage)((X), (Y))

//dizileri yazdırmak için makro
#define printArray(X, Y) _Generic((X), \
  char *: printArrayCHAR, \
  int *: printArrayINT, \
  unsigned int *: printArrayUNSIGNEDINT, \
  short int *: printArraySHORTINT, \
  long int *: printArrayLONGINT, \
  long long int *: printArrayLONGLONGINT, \
  CustomModel *: printArrayCUSTOM, \
  default: errorMessage)((X), (Y))



//custom model üst sınırı, veri dizisini,boyutunu ve model tipini barındırır. model tipine göre void* yerine uygun tip dönüşümü yapılır.
typedef struct CustomModel {
  void * data;
  int max;
  int size;
  int modelTip;
}
CustomModel;


// model tipleri enumu. CustomModelin tiplerini tutar. custom bu listeden herhangi bir tipte veri tutabilir.
enum modelType {
  charModel,
  intModel,
  longIntModel,
  shortModel,
  unsignedModel,
  longLongModel
};


void countingSortCHAR(char input[], int size);

void countingSortINT(int input[], int size);

void countingSortLONGINT(long int input[], int size);

void countingSortSHORTINT(short int input[], int size);

void countingSortUNSIGNEDINT(unsigned int input[], int size);

void countingSortLONGLONGINT(long long int* input, int size); // büyük sayılarda segmentasyon hatası verdiği için pointera çevirildi.

void countingSortCUSTOM(CustomModel * model, int size);


// verilen veriler ile model oluşturur.
CustomModel * createModel(void * data, int max, int size, int modelTip);


int findRangeINT(int arr[], int size);

long int findRangeLONGINT(long int arr[], int size);

short int findRangeSHORTINT(short int arr[], int size);

unsigned int findRangeUNSIGNEDINT(unsigned int arr[], int size);

long long int findRangeLONGLONGINT(long long int* arr, int size);

long long int findRangeCUSTOM(CustomModel * model, int size);

int returnCharRange();


void printArrayINT(int input[], int size);

void printArrayLONGINT(long int input[], int size);

void printArraySHORTINT(short int input[], int size);

void printArrayUNSIGNEDINT(unsigned int input[], int size);

void printArrayLONGLONGINT(long long int *  input, int size);

void printArrayCUSTOM(CustomModel * model, int size);

void printArrayCHAR(char input[], int size);

int errorMessage();

#endif/* counting_h */

