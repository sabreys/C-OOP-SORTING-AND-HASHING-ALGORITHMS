#ifndef __ELF_H__
#define __ELF_H__

#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#include <assert.h>


/* Elf Hash Kütüphanesi
 * Elf hash linux sistemlerinde kullanılan bir özetleme algoritmasıdır.
 * Bu kütüphane char, int, float, double, long long int  ve custom structlar için hashleme işlemine imkan verir.
 * Programlamada Ozel Konular Dersi 
 */

#define elfHash(X, Y) _Generic((X), \
  char *: elfHashSTR, \
  int: elfHashINT, \
  float: elfHashFLOAT, \
  double: elfHashDOUBLE, \
  long int: elfHashLONGINT, \
  Elfnode *: elfHashCUSTOM, \
  default: errorMessage)((X), (Y))

#define elfHashTableAdd(X, Y, Z) _Generic((Y), \
  char *: elfHashTableAddSTR, \
  int: elfHashTableAddINT, \
  float: elfHashTableAddFLOAT, \
  double: elfHashTableAddDOUBLE, \
  long int: elfHashTableAddLONGINT, \
  Elfnode *: elfHashTableAddCUSTOM, \
  default: errorMessage)((X), (Y), (Z))

#define elfHashTableRemove(X, Y, Z) _Generic((Y), \
  char *: elfHashTableRemoveSTR, \
  int: elfHashTableRemoveINT, \
  float: elfHashTableRemoveFLOAT, \
  double: elfHashTableRemoveDOUBLE, \
  long int: elfHashTableRemoveLONGINT, \
  Elfnode *: elfHashTableRemoveCUSTOM, \
  default: errorMessage)((X), (Y), (Z))

#define elfHashTableSearch(X, Y, Z) _Generic((Y), \
  char *: elfHashTableSearchSTR, \
  int: elfHashTableSearchINT, \
  float: elfHashTableSearchFLOAT, \
  double: elfHashTableSearchDOUBLE, \
  long int: elfHashTableSearchLONGINT, \
  Elfnode *: elfHashTableSearchCUSTOM, \
  default: errorMessage)((X), (Y), (Z))

// örnek struct modeli. veri,uzunluğu ve hash sonucunu içinde barındırır.
typedef struct ElfModel {
  char * data;
  long length;
  int hash_result;
}
Elfnode;

typedef struct {
  int * array;
  size_t used;
  size_t size;
}
HashTable;

// hash karşılaştırma fonksiyonu için sonuç değerleri. başarısız 0, başarılı 1 
enum sonuc {
  basarisiz,
  basarili
};

void freeHashTable(HashTable * a);

// hash tablosunu yaratır.
void initHashTable(HashTable * a, size_t initialSize);

// Stringler için elf hash fonksiyonu
int elfHashSTR(char * str, long length);
// int için elf hash fonksiyonu
int elfHashINT(int str, long length);
// float için elf hash fonksiyonu
int elfHashFLOAT(float str, long length);
//double için elf hash fonksiyonu
int elfHashDOUBLE(double str, long length);
// long int için elf hash fonksiyonu
int elfHashLONGINT(long int str, long length);
// custom struct için elf hash fonksiyonu
int elfHashCUSTOM(Elfnode * str, long length);

void elfHashTableAddSTR(HashTable * table, char * str, long length);

void elfHashTableAddINT(HashTable * table, int str, long length);

void elfHashTableAddFLOAT(HashTable * table, float str, long length);

void elfHashTableAddDOUBLE(HashTable * table, double str, long length);

void elfHashTableAddLONGINT(HashTable * table, long int str, long length);

void elfHashTableAddCUSTOM(HashTable * table, Elfnode * str, long length);

void elfHashTableRemoveSTR(HashTable * table, char * str, long length);

void elfHashTableRemoveINT(HashTable * table, int str, long length);

void elfHashTableRemoveFLOAT(HashTable * table, float str, long length);

void elfHashTableRemoveDOUBLE(HashTable * table, double str, long length);

void elfHashTableRemoveLONGINT(HashTable * table, long int str, long length);

void elfHashTableRemoveCUSTOM(HashTable * table, Elfnode * str, long length);

int elfHashTableSearchSTR(HashTable * table, char * str, long length);

int elfHashTableSearchINT(HashTable * table, int str, long length);

int elfHashTableSearchFLOAT(HashTable * table, float str, long length);

int elfHashTableSearchDOUBLE(HashTable * table, double str, long length);

int elfHashTableSearchLONGINT(HashTable * table, long int str, long length);

int elfHashTableSearchCUSTOM(HashTable * table, Elfnode * str, long length);

void printHashTable(HashTable * table);

void resizeHashTable(HashTable * table);

// verilen data ile node oluşturur,verinin uzunluğunu veriler ve hashleme işlemi yapıp node un içine kaydeder.
Elfnode * create_node(char * data);

// verilen metinin verilen hashle uyumuna bakar.
int checkHash(char * str1, int hash);

// hata mesajı döndürür. -1 döner.
int errorMessage();

#endif /* elf_h */