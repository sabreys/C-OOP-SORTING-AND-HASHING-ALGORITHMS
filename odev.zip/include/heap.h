#ifndef __HEAP_H__
#define __HEAP_H__

#include <stdio.h>

#include <string.h>

#include <stdlib.h>


/* Heap Sort K�t�phanesi
* Verileri, veri karmasikligi ve yer karmasikligi problemlerini cozmek amaciyla siralayan cesitli siralama algoritmalarindan biridir.
* Programlamada Ozel Konular Dersi 
* 
*/

// Genericler
#define heapify(X, Y, Z) _Generic((X), \
  char *: heapifyCHAR, \
  int *: heapifyINT, \
  float *: heapifyFLOAT, \
  double *: heapifyDOUBLE, \
  default: errorMessageHEAPIFY)((X), (Y), (Z))

#define heapSort(X, Y) _Generic((X), \
  char *: heapSortCHAR, \
  int *: heapSortINT, \
  float *: heapSortFLOAT, \
  double *: heapSortDOUBLE, \
  default: errorMessageHEAPSORT)((X), (Y))

#define printArray(X, Y) _Generic((X), \
  char *: printCharArray, \
  int *: printIntArray, \
  float *: printArrayFLOAT, \
  double *: printArrayDOUBLE, \
  default: errorMessages)((X), (Y))

#define swapPair(X, Y) _Generic((X), \
  char *: swapCHAR, \
  int *: swapINT, \
  float *: swapFLOAT, \
  double *: swapDOUBLE, \
  default: errorMessageSWAP)((X), (Y))

void swapINT(int * a, int * b);
void swapFLOAT(float * a, float * b);
void swapDOUBLE(double * a, double * b);
void swapCHAR(char * a, char * b);

void heapifyINT(int arr[], int n, int i);
void heapifyFLOAT(float arr[], int n, int i);
void heapifyDOUBLE(double arr[], int n, int i);
void heapifyCHAR(char arr[], int n, int i);

void heapSortINT(int arr[], int n);
void heapSortFLOAT(float arr[], int n);
void heapSortDOUBLE(double arr[], int n);
void heapSortCHAR(char arr[], int n);

void printArrayFLOAT(float input[], int size);
void printArrayDOUBLE(double input[], int size);
void printCharArray(char input[], int size);
void printIntArray(int input[], int size);

// hata mesaji dondurur -1 doner.
int errorMessages();
int errorMessageHEAPIFY();
int errorMessageHEAPSORT();
int errorMessageSWAP();
#endif /* heap_h */
