#ifndef __XORLL_H__
#define __XORLL_H__

#define big(a, b) a < b
#define BIG(a, b) big(a, b)

#define init(X) _Generic((X), \
  int: initINT, \
  float: initFLOAT, \
  char: initCHAR, \
  double: initDOUBLE, \
  default: typeError)(X)

#define ekle(X, Y) _Generic((Y), \
  int: ekleINT, \
  float: ekleFLOAT, \
  char: ekleCHAR, \
  double: ekleDOUBLE, \
  default: typeError)((X), (Y))

// XOR linled list düğümü
typedef struct node {
  void * data; // veri 
  struct node * npx; // once ve sonra olan nodelerin XOR
  int type;
}
node_ll;

enum XorllTypes {
  intll,
  floatll,
  charll,
  doublell
};

node_ll * XOR(node_ll * , node_ll * );

node_ll * initINT(int val);
node_ll * initFLOAT(float val);
node_ll * initCHAR(char val);
node_ll * initDOUBLE(double val);

void yazdirList(node_ll * );

void ekleINT(node_ll ** , int val);
void ekleFLOAT(node_ll ** , float val);
void ekleCHAR(node_ll ** , char val);
void ekleDOUBLE(node_ll ** , double val);

void max(node_ll * );
void min(node_ll * );
void delEnd(node_ll ** );

int typeError();

#endif //__XORll_H__