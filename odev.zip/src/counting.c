#include "counting.h"
#include <assert.h>

//verilen char dizisini sayma_dizisiing sort algoritması ile sıralar.
void countingSortCHAR(char input[], int size) {
    if(size == 0 ){
    printf("dizide eleman yok .\n");
    return;
  }
  
  
  #ifdef DEBUG
   assert(size != 0 );
  #endif
  // sıralanmış çıktı dizisi
  char output[strlen(input)];

  //tüm elemanların boyutunda sayma dizisi. 
  // bu dizi üzerinde var olan elemanların adetleri tutulur.
  int sayma_dizisi[RANGE + 1], i;
  memset(sayma_dizisi, 0, sizeof(sayma_dizisi)); //0 ile dolu dizi oluşturuyoruz.

  // input dizisini sayma dizisi üzerinde işaretler
  for (i = 0; input[i]; ++i)
    ++sayma_dizisi[input[i]];

  //sayma dizisindeki konumları asıl yerine kaydırır. 
  for (i = 1; i <= RANGE; ++i)
    sayma_dizisi[i] += sayma_dizisi[i - 1];

  // sonuc dizisini hazirlar.
  for (i = 0; input[i]; ++i) {
    output[sayma_dizisi[input[i]] - 1] = input[i];
    --sayma_dizisi[input[i]];
  }

  // sonuc dizisini asıl diziye geçirir.
  for (i = 0; input[i]; ++i)
    input[i] = output[i];
}

// char değerlerin üst aralığını döndürür. 255 
int returnCharRange() {
  return RANGE;
}

//dizideki en büyük int sayıyı bularak döndürür.
int findRangeINT(int arr[], int size) {

  int biggest = arr[0]; //ilk eleman en büyük kabul edilir.
  for (int i = 1; i < size; i++) { // tüm diziyi gez ve büyük olanları seçip biggesta ata.
    if (arr[i] > biggest) {
      biggest = arr[i];
    }
  }

  return biggest;

}

//dizideki en büyük sayıyı bularak döndürür.
long int findRangeLONGINT(long int arr[], int size) {
  long int biggest = arr[0];
  for (int i = 1; i < size; i++) {
    if (arr[i] > biggest) {
      biggest = arr[i];
    }
  }

  return biggest;
}
//dizideki en büyük sayıyı bularak döndürür.
unsigned int findRangeUNSIGNEDINT(unsigned int arr[], int size) {
  signed int biggest = arr[0];
  for (int i = 1; i < size; i++) {
    if (arr[i] > biggest) {
      biggest = arr[i];
    }
  }

  return biggest;
}
//dizideki en büyük sayıyı bularak döndürür.
short int findRangeSHORTINT(short int arr[], int size) {
  short int biggest = arr[0];
  for (int i = 1; i < size; i++) {
    if (arr[i] > biggest) {
      biggest = arr[i];
    }
  }

  return biggest;
}
//dizideki en büyük sayıyı bularak döndürür.
long long int findRangeLONGLONGINT(long long int* arr, int size) {
  long long int biggest = arr[0];
  for (long long int  i = 1; i < size; i++) {
    if (arr[i] > biggest) {
      biggest = arr[i];
    }
  }

  return biggest;
}
//dizideki en büyük sayıyı bularak döndürür.
long long int findRangeCUSTOM(CustomModel * model, int size) {
  //tip dönüşümü ile void*dan getirilen sonuç dizileri.switch içinde tanımlanamadığı için burada yazıldı.
  int * arr1;
  long int * arr2;
  short int * arr3;
  unsigned int * arr4;
  long long int * arr5;
  // modelin tipine göre uygun fonksiyona yönlendirir.
  switch (model -> modelTip) {
  case charModel:

    return RANGE;
    break;

  case intModel:
    arr1 = (int * ) model -> data;

    return findRange(arr1, size);

    break;

  case longIntModel:
    arr2 = (long int * ) model -> data;

    return findRange(arr2, size);

    break;

  case shortModel:
    arr3 = (short int * ) model -> data;

    return findRange(arr3, size);

    break;

  case unsignedModel:
    arr4 = (unsigned int * ) model -> data;

    return findRange(arr4, size);

    break;

  case longLongModel:

    arr5 = (long long int * ) model -> data;

    return findRange(arr5, size);

    break;

  default:
    errorMessage();
    return 0;
  }

}


void countingSortINT(int input[], int size) {
   
  if(size == 0 ){
    printf("dizide eleman yok .\n");
    return;
  }
  

  #ifdef DEBUG
   assert(size != 0 );
  #endif
 
  //çıktı dizisi
  int output[size];
  // aralığı kısıtlamak için en büyük elemanı buluyoruz
  int biggest = findRange(input, size);
  // sayma dizisi
  int count[biggest + 1];
  // sayma dizisini 0 ile doldur
  for (int i = 0; i <= biggest; ++i) {
    count[i] = 0;
  }
  //count dizisine elemanları saydır
  for (int i = 0; i < size; i++) {
    count[input[i]]++;
  }
  // indis kaydırma
  for (int i = 1; i <= biggest; i++) {
    count[i] += count[i - 1];
  }
  //output dizisini hazırlama. sıralı şekilde dizer
  for (int i = size - 1; i >= 0; i--) {
    output[count[input[i]] - 1] = input[i];
    count[input[i]]--;
  }
  // çıktıyı ilk verilen diziye aktarır. üzerine yazar
  for (int i = 0; i < size; i++) {
    input[i] = output[i];
  }

}

void countingSortLONGINT(long int input[], int size) {

  if(size == 0 ){
    printf("dizide eleman yok .\n");
    return;
  }
  
  
  #ifdef DEBUG
   assert(size != 0 );
  #endif
 
  //çıktı dizisi
  long int output[size];
  // aralığı kısıtlamak için en büyük elemanı buluyoruz
  long int biggest = findRange(input, size);
  // sayma dizisi
  long int count[biggest + 1];
  // sayma dizisini 0 ile doldur
  for (long int i = 0; i <= biggest; ++i) {
    count[i] = 0;
  }
  //count dizisine elemanları saydır
  for (long int i = 0; i < size; i++) {
    count[input[i]]++;
  }
  // indis kaydırma
  for (long int i = 1; i <= biggest; i++) {
    count[i] += count[i - 1];
  }
  //output dizisini hazırlama. sıralı şekilde dizer
  for (long int i = size - 1; i >= 0; i--) {
    output[count[input[i]] - 1] = input[i];
    count[input[i]]--;
  }
  // çıktıyı ilk verilen diziye aktarır. üzerine yazar
  for (long int i = 0; i < size; i++) {
    input[i] = output[i];
  }
}

void countingSortSHORTINT(short int input[], int size) {

    if(size == 0 ){
    printf("dizide eleman yok .\n");
    return;
  }
  
  
  #ifdef DEBUG
   assert(size != 0 );
  #endif


  //çıktı dizisi
  short int output[size];
  // aralığı kısıtlamak için en büyük elemanı buluyoruz
  short int biggest = findRange(input, size);
  // sayma dizisi
  short int count[biggest + 1];
  // sayma dizisini 0 ile doldur
  for (short int i = 0; i <= biggest; ++i) {
    count[i] = 0;
  }
  //count dizisine elemanları saydır
  for (short int i = 0; i < size; i++) {
    count[input[i]]++;
  }
  // indis kaydırma
  for (short int i = 1; i <= biggest; i++) {
    count[i] += count[i - 1];
  }
  //output dizisini hazırlama. sıralı şekilde dizer
  for (short int i = size - 1; i >= 0; i--) {
    output[count[input[i]] - 1] = input[i];
    count[input[i]]--;
  }
  // çıktıyı ilk verilen diziye aktarır. üzerine yazar
  for (short int i = 0; i < size; i++) {
    input[i] = output[i];
  }
}

void countingSortUNSIGNEDINT(unsigned int input[], int size) {

    if(size == 0 ){
    printf("dizide eleman yok .\n");
    return;
  }
  
  
  #ifdef DEBUG
   assert(size != 0 );
  #endif
 
  //çıktı dizisi
  unsigned int output[size];
  // aralığı kısıtlamak için en büyük elemanı buluyoruz
  unsigned int biggest = findRange(input, size);
  // sayma dizisi
  unsigned int count[biggest + 1];
  // sayma dizisini 0 ile doldur
  for (int i = 0; i <= biggest; ++i) {
    count[i] = 0;
  }
  //count dizisine elemanları saydır
  for (int i = 0; i < size; i++) {
    count[input[i]]++;
  }
  // indis kaydırma
  for (int i = 1; i <= biggest; i++) {
    count[i] += count[i - 1];
  }
  //output dizisini hazırlama. sıralı şekilde dizer
  for (int i = size - 1; i >= 0; i--) {
    output[count[input[i]] - 1] = input[i];
    count[input[i]]--;
  }
  // çıktıyı ilk verilen diziye aktarır. üzerine yazar
  for (int i = 0; i < size; i++) {
    input[i] = output[i];
  }
}

void countingSortLONGLONGINT(long long int* input, int size) {

    if(size == 0 ){
    printf("dizide eleman yok .\n");
    return;
  }
  
  
  #ifdef DEBUG
   assert(size != 0 );
  #endif

 
  //çıktı dizisi
  long long int* output = malloc(sizeof(*output )*size);
  // aralığı kısıtlamak için en büyük elemanı buluyoruz
  long long int biggest = findRange(input, size);
  // sayma dizisi
  long long int* count = malloc(sizeof(*count)*(biggest+1));
  // sayma dizisini 0 ile doldur
  for (long long int i = 0; i <= biggest; ++i) {
    count[i] = 0;
  }
  //count dizisine elemanları saydır
  for (long long int i = 0; i < size; i++) {
    count[input[i]]++;
  }
  // indis kaydırma
  for (long long int i = 1; i <= biggest; i++) {
    count[i] += count[i - 1];
  }
  //output dizisini hazırlama. sıralı şekilde dizer
  for (long long int i = size - 1; i >= 0; i--) {
    output[count[input[i]] - 1] = input[i];
    count[input[i]]--;
  }
  // çıktıyı ilk verilen diziye aktarır. üzerine yazar
  for (long long int i = 0; i < size; i++) {
    input[i] = output[i];
  }
}

// struct modelini uygun tipe göre yönlendirir ve sort işlemini yapar.
void countingSortCUSTOM(CustomModel * model, int size) {

    if(size == 0 ){
    printf("dizide eleman yok .\n");
    return;
  }
  
  
  #ifdef DEBUG
   assert(size != 0 );
  #endif


  switch (model -> modelTip) {

  case charModel:
    countingSort((char * ) model -> data, size);
    break;

  case intModel:

    countingSort((int * ) model -> data, size);
    break;

  case longIntModel:

    countingSort((long int * ) model -> data, size);
    break;

  case shortModel:

    countingSort((short * ) model -> data, size);

    break;

  case unsignedModel:

    countingSort((unsigned * ) model -> data, size);

    break;

  case longLongModel:

    countingSort((long long int * ) model -> data, size);

    break;

  default:
    errorMessage();

  }

}


 // dizi yazdırma fonksiyonu.
void printArrayCHAR(char input[], int size) {

  if(size == 0 ){
    printf("dizi boş.\n");
    return;
  }
  
  
  #ifdef DEBUG
   assert(size != 0 );
  #endif

  printf("char dizisi:");
  printf("%s\n", input);
}
 // dizi yazdırma fonksiyonu.
void printArrayINT(int input[], int size) {

   if(size == 0 ){
    printf("dizi boş.\n");
    return;
  }
  
  
  #ifdef DEBUG
   assert(size != 0 );
  #endif


    printf("int  dizisi:");
  for (int i = 0; i < size; i++) {
    printf("%d,", input[i]);
  }
  printf("\n");
}

// yanlış tip durumunda hata mesajı yazar ve -1 döner
int errorMessage() {
  printf("tip hatası\n");
  return -1;
}



 // dizi yazdırma fonksiyonu.
void printArrayLONGINT(long int input[], int size) {
   if(size == 0 ){
    printf("dizi boş.\n");
    return;
  }
  
  
  #ifdef DEBUG
   assert(size != 0 );
  #endif

    printf("long int dizisi:");
  for (int i = 0; i < size; i++) {
    printf("%ld,", input[i]);
  }
  printf("\n");
}
 // dizi yazdırma fonksiyonu.
void printArraySHORTINT(short int input[], int size) {

   if(size == 0 ){
    printf("dizi boş.\n");
    return;
  }
  
  
  #ifdef DEBUG
   assert(size != 0 );
  #endif


    printf("short int dizisi:");
  for (int i = 0; i < size; i++) {
    printf("%d,", input[i]);
  }
  printf("\n");
}
 // dizi yazdırma fonksiyonu.
void printArrayUNSIGNEDINT(unsigned int input[], int size) {
   if(size == 0 ){
    printf("dizi boş.\n");
    return;
  }
  
  
  #ifdef DEBUG
   assert(size != 0 );
  #endif


    printf("unsigned int dizisi:");
  for (int i = 0; i < size; i++) {
    printf("%d,", input[i]);
  }
  printf("\n");
}
 // dizi yazdırma fonksiyonu.
void printArrayLONGLONGINT(long long int input[], int size) {

   if(size == 0 ){
    printf("dizi boş.\n");
    return;
  }
  
  
  #ifdef DEBUG
   assert(size != 0 );
  #endif


    printf("long long int  dizisi:");
  for (int i = 0; i < size; i++) {
    printf("%lld,", input[i]);
  }
  printf("\n");
}
 // dizi yazdırma fonksiyonu. doğru tipe göre aktarma yaparak uygun fonksiyona yönlendirir.
void printArrayCUSTOM(CustomModel * model, int size) {

  


    printf("custom struct  ve tipi ");

  switch (model -> modelTip) {

  case charModel:
    printArray((char * ) model -> data, size);
    break;

  case intModel:
    printArray((int * ) model -> data, size);
    break;

  case longIntModel:
    printArray((long int * ) model -> data, size);
    break;

  case shortModel:
    printArray((short int * ) model -> data, size);

    break;

  case unsignedModel:

    printArray((unsigned int * ) model -> data, size);
    break;

  case longLongModel:

    printArray((long long int * ) model -> data, size);

    break;

  default:
    errorMessage();
    break;

  }

}
 // verilen parametrelerle model oluşturur. uygun tipe göre  generic olarak çalışır.
CustomModel * createModel(void * data, int max, int size, int modelTip) {


  CustomModel * model = (CustomModel * ) malloc(sizeof(CustomModel));

  switch (modelTip) {

  case charModel:

    model -> data = (char * ) data;
    model -> size = size;
    model -> modelTip = modelTip;

    break;

  case intModel:

    model -> data = (int * ) data;
    model -> size = size;
    model -> modelTip = modelTip;

    break;

  case longIntModel:

    model -> data = (long int * ) data;
    model -> size = size;
    model -> modelTip = modelTip;

    break;

  case shortModel:

    model -> data = (short * ) data;
    model -> size = size;
    model -> modelTip = modelTip;

    break;

  case unsignedModel:

    model -> data = (unsigned int * ) data;
    model -> size = size;
    model -> modelTip = modelTip;

    break;

  case longLongModel:

    model -> data = (long long int * ) data;
    model -> size = size;
    model -> modelTip = modelTip;

    break;

  default:
    errorMessage();
    break;

  }

  return model;

}