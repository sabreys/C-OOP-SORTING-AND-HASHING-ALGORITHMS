#include "elf.h"

/*  elfHash kütüphanesi  
 *   ELF hash fonksiyonu PJW Hash fonksiyonuna benzer bir özetleme fonksiyonudur.32 bit işlemciler için tasarlanmıştır. 
 *   UNIX  tabanlı işletim sistemlerinde kullanılır.
 *   Bu kütüphane elf hash oluşturma ve kıyaslama fonksiyonlarını içerir.
 *   12.grup Programlamada özel konular dersi 2021 yaz dönemi.
 */

int elfHashSTR(char * str, long length) {
  #ifdef DEBUG
  printf("haslenecek icerik (String):%s\n", str);
  #endif
  int result = 0; //hash sonucudur.
  long holder = 0;
  long index = 0; //döngü için index değeridir.girdi uzunluğu kadar artar.

  // 0 dan uzunluğa kadar 1 artan döngü. sırayla tüm indisleri gezerek hashleme işlemini gerçekleştirir. length kadar çalışır.

  for (index = 0; index < length; ++str, ++index) {

    result = (result << 4) + ( * str); // result değerini 4 kez sola kaydır ve girdinin indexdeki değerini topla çıkan sonucu resulta eşitle

    // eğer result ile  4026531840(11110000000000000000000000000000)32 bit uzunluğundaki  değerinin ve işlemi sonucu 0 çıkmıyorsa yap 
    //
    if ((holder = result & 0xF0000000L) != 0) {

      result ^= (holder >> 24); // holderi 24 bit sağa kaydır ve oluşan sonucu result değeri ile bit düzeyinde xorla.
    }

    result &= ~holder; // bit bazında ve işlemi. holder in tersi ile result bit düzeyinde ve lenir.

  }

  return result;
}

int elfHashINT(int str, long length) {

  int result = 0; //hash sonucudur.
  long holder = 0;
  long index = 0; //döngü için index değeridir.girdi uzunluğu kadar artar.

  // int değeri stringe çevirir.
  char * converted = malloc(length + 1); // yer alma işlemi. kaçış işareti için +1
  snprintf(converted, length + 1, "%d", str);

  #ifdef DEBUG
  printf("haslenecek icerik (int):%s\n", converted);
  #endif

  // 0 dan uzunluğa kadar 1 artan döngü. sırayla tüm indisleri gezerek hashleme işlemini gerçekleştirir. length kadar çalışır.

  for (index = 0; index < length; ++converted, ++index) {

    result = (result << 4) + ( * converted); // result değerini 4 kez sola kaydır ve girdinin indexdeki değerini topla çıkan sonucu resulta eşitle

    // eğer result ile  4026531840(11110000000000000000000000000000)32 bit uzunluğundaki  değerinin ve işlemi sonucu 0 çıkmıyorsa yap 
    //
    if ((holder = result & 0xF0000000L) != 0) {

      result ^= (holder >> 24); // holderi 24 bit sağa kaydır ve oluşan sonucu result değeri ile bit düzeyinde xorla.
    }

    result &= ~holder; // bit bazında ve işlemi. holder in tersi ile result bit düzeyinde ve lenir.

  }

  return result;
}

int elfHashFLOAT(float str, long length) {

  int result = 0; //hash sonucudur.
  long holder = 0;
  long index = 0; //döngü için index değeridir.girdi uzunluğu kadar artar.

  // float değeri stringe çevirir.
  char * converted = malloc(length + 1); // yer alma işlemi. kaçış işareti için +1
  snprintf(converted, length + 1, "%f", str);

  // float da uzunluğun yanlış belirlenmesinin önüne geçmek için. 
  #ifdef DEBUG
  printf("haslenecek icerik (float):%s \n", converted);
  #endif
  // 0 dan uzunluğa kadar 1 artan döngü. sırayla tüm indisleri gezerek hashleme işlemini gerçekleştirir. length kadar çalışır.

  for (index = 0; index < length; ++converted, ++index) {

    result = (result << 4) + ( * converted); // result değerini 4 kez sola kaydır ve girdinin indexdeki değerini topla çıkan sonucu resulta eşitle

    // eğer result ile  4026531840(11110000000000000000000000000000)32 bit uzunluğundaki  değerinin ve işlemi sonucu 0 çıkmıyorsa yap 
    //
    if ((holder = result & 0xF0000000L) != 0) {

      result ^= (holder >> 24); // holderi 24 bit sağa kaydır ve oluşan sonucu result değeri ile bit düzeyinde xorla.
    }

    result &= ~holder; // bit bazında ve işlemi. holder in tersi ile result bit düzeyinde ve lenir.

  }

  return result;
}

int elfHashDOUBLE(double str, long length) {

  int result = 0; //hash sonucudur.
  long holder = 0;
  long index = 0; //döngü için index değeridir.girdi uzunluğu kadar artar.

  // double değeri stringe çevirir.
  char * converted = malloc(length + 1); // yer alma işlemi. kaçış işareti için +1
  snprintf(converted, length + 1, "%lf", str);

  // float da uzunluğun yanlış belirlenmesinin önüne geçmek için. 
  #ifdef DEBUG
  printf("haslenecek icerik (double):%s \n", converted);
  #endif
  // 0 dan uzunluğa kadar 1 artan döngü. sırayla tüm indisleri gezerek hashleme işlemini gerçekleştirir. length kadar çalışır.

  for (index = 0; index < length; ++converted, ++index) {

    result = (result << 4) + ( * converted); // result değerini 4 kez sola kaydır ve girdinin indexdeki değerini topla çıkan sonucu resulta eşitle

    // eğer result ile  4026531840(11110000000000000000000000000000)32 bit uzunluğundaki  değerinin ve işlemi sonucu 0 çıkmıyorsa yap 
    //
    if ((holder = result & 0xF0000000L) != 0) {

      result ^= (holder >> 24); // holderi 24 bit sağa kaydır ve oluşan sonucu result değeri ile bit düzeyinde xorla.
    }

    result &= ~holder; // bit bazında ve işlemi. holder in tersi ile result bit düzeyinde ve lenir.

  }

  return result;
}

int elfHashLONGINT(long int str, long length) {

  int result = 0; //hash sonucudur.
  long holder = 0;
  long index = 0; //döngü için index değeridir.girdi uzunluğu kadar artar.

  // long int değeri stringe çevirir.
  char * converted = malloc(length + 1); // yer alma işlemi. kaçış işareti için +1
  snprintf(converted, length + 1, "%li", str);

  // float da uzunluğun yanlış belirlenmesinin önüne geçmek için. 
  #ifdef DEBUG
  printf("haslenecek icerik (long int):%s \n", converted);
  #endif
  // 0 dan uzunluğa kadar 1 artan döngü. sırayla tüm indisleri gezerek hashleme işlemini gerçekleştirir. length kadar çalışır.

  for (index = 0; index < length; ++converted, ++index) {

    result = (result << 4) + ( * converted); // result değerini 4 kez sola kaydır ve girdinin indexdeki değerini topla çıkan sonucu resulta eşitle

    // eğer result ile  4026531840(11110000000000000000000000000000)32 bit uzunluğundaki  değerinin ve işlemi sonucu 0 çıkmıyorsa yap 
    //
    if ((holder = result & 0xF0000000L) != 0) {

      result ^= (holder >> 24); // holderi 24 bit sağa kaydır ve oluşan sonucu result değeri ile bit düzeyinde xorla.
    }

    result &= ~holder; // bit bazında ve işlemi. holder in tersi ile result bit düzeyinde ve lenir.

  }

  return result;
}

// Hash Tablosunu boyutlandırır. 
void resizeHashTable(HashTable * table) {
  #ifdef DEBUG
  assert(table -> used >= 0);
  #endif

  if (table -> used < 0) {
    printf("hash table boş. resize yapılmadı.\n");
    return;
  }

  if (table -> used == 0) {
    table -> used == 1;
    table -> size == 1;
  }
  table -> array = realloc(table -> array, table -> used * sizeof(int));

  table -> size = table -> used;

}

int elfHashCUSTOM(Elfnode * str, long length) {

  int result = 0; //hash sonucudur.
  long holder = 0;
  long index = 0; //döngü için index değeridir.girdi uzunluğu kadar artar.

  char * converted = str -> data;
  #ifdef DEBUG
  printf("haslenecek icerik (CUSTOM):%s \n", converted);
  #endif
  // 0 dan uzunluğa kadar 1 artan döngü. sırayla tüm indisleri gezerek hashleme işlemini gerçekleştirir. length kadar çalışır.

  for (index = 0; index < length; ++converted, ++index) {

    result = (result << 4) + ( * converted); // result değerini 4 kez sola kaydır ve girdinin indexdeki değerini topla çıkan sonucu resulta eşitle

    // eğer result ile  4026531840(11110000000000000000000000000000)32 bit uzunluğundaki  değerinin ve işlemi sonucu 0 çıkmıyorsa yap 
    //
    if ((holder = result & 0xF0000000L) != 0) {

      result ^= (holder >> 24); // holderi 24 bit sağa kaydır ve oluşan sonucu result değeri ile bit düzeyinde xorla.
    }

    result &= ~holder; // bit bazında ve işlemi. holder in tersi ile result bit düzeyinde ve lenir.

  }

  str -> hash_result = result;

  return result;
}

// Hash table oluşturma fonksiyonu
void initHashTable(HashTable * a, size_t initialSize) {
  
  #ifdef DEBUG
  assert(a != NULL);
  #endif

  if(a== NULL){
    printf("Tablo NULL !\n");
    return;
  }

  a -> array = malloc(initialSize * sizeof(int));
  a -> used = 0;
  a -> size = initialSize;
}

void elfHashTableAddSTR(HashTable * table, char * str, long length) {
  #ifdef DEBUG
  assert(table != NULL);
  assert(strcmp("", str) != 0);
  #endif

  if(table == NULL){
    printf("Tablo NULL!\n");
    return;
  }

  if(strcmp("", str) == 0){
    printf("Boş String !\n");
    return;
  }



  int hash_result = elfHash(str, length);

  int indeks = elfHashTableSearch(table, str, length);

  if (indeks != -1) {
    printf("Çakışma var. ekleme yapılamadı çakışan indeks: %d \n", indeks);
    #ifdef DEBUG
    assert(indeks != -1);
    #endif
    return;
  }

  if (table -> used == table -> size) {
    table -> size *= 2;
    table -> array = realloc(table -> array, table -> size * sizeof(int));
  }
  table -> array[table -> used++] = hash_result;
  resizeHashTable(table);

  #ifdef DEBUG
  printf("eklenen: %d , size : %d , used : %d \n", hash_result, table -> size, table -> used);
  #endif

}

void elfHashTableAddINT(HashTable * table, int str, long length) {
  assert(table != NULL);

  int hash_result = elfHash(str, length);

  int indeks = elfHashTableSearch(table, str, length);

  if (indeks != -1) {
    printf("Çakışma var. ekleme yapılamadı çakışan indeks: %d \n", indeks);
    #ifdef DEBUG
    assert(indeks != -1);
    #endif
    return;
  }

  if (table -> used == table -> size) {
    table -> size *= 2;
    table -> array = realloc(table -> array, table -> size * sizeof(int));
  }
  table -> array[table -> used++] = hash_result;

  resizeHashTable(table);

  #ifdef DEBUG
  printf("eklenen: %d , size : %d , used : %d \n", hash_result, table -> size, table -> used);
  #endif
}

void elfHashTableAddFLOAT(HashTable * table, float str, long length) {
  assert(table != NULL);

  int hash_result = elfHash(str, length);

  int indeks = elfHashTableSearch(table, str, length);

  if (indeks != -1) {
    printf("Çakışma var. ekleme yapılamadı çakışan indeks: %d \n", indeks);
    #ifdef DEBUG
    assert(indeks != -1);
    #endif
    return;
  }

  if (table -> used == table -> size) {
    table -> size *= 2;
    table -> array = realloc(table -> array, table -> size * sizeof(int));
  }
  table -> array[table -> used++] = hash_result;

  resizeHashTable(table);

  #ifdef DEBUG
  printf("eklenen: %d , size : %d , used : %d \n", hash_result, table -> size, table -> used);
  #endif

}

void elfHashTableAddDOUBLE(HashTable * table, double str, long length) {
  assert(table != NULL);

  int hash_result = elfHash(str, length);

  int indeks = elfHashTableSearch(table, str, length);

  if (indeks != -1) {
    printf("Çakışma var. ekleme yapılamadı çakışan indeks: %d \n", indeks);
    #ifdef DEBUG
    assert(indeks != -1);
    #endif
    return;
  }

  if (table -> used == table -> size) {
    table -> size *= 2;
    table -> array = realloc(table -> array, table -> size * sizeof(int));
  }
  table -> array[table -> used++] = hash_result;

  resizeHashTable(table);

  #ifdef DEBUG
  printf("eklenen: %d , size : %d , used : %d \n", hash_result, table -> size, table -> used);
  #endif

}

void elfHashTableAddLONGINT(HashTable * table, long int str, long length) {
  assert(table != NULL);

  int hash_result = elfHash(str, length);

  int indeks = elfHashTableSearch(table, str, length);

  if (indeks != -1) {
    printf("Çakışma var. ekleme yapılamadı çakışan indeks: %d \n", indeks);
    #ifdef DEBUG
    assert(indeks != -1);
    #endif
    return;
  }

  if (table -> used == table -> size) {
    table -> size *= 2;
    table -> array = realloc(table -> array, table -> size * sizeof(int));
  }
  table -> array[table -> used++] = hash_result;
  resizeHashTable(table);

  #ifdef DEBUG
  printf("eklenen: %d , size : %d , used : %d \n", hash_result, table -> size, table -> used);
  #endif

}

void elfHashTableAddCUSTOM(HashTable * table, Elfnode * str, long length) {
  assert(table != NULL);

  int hash_result = elfHash(str, length);

  int indeks = elfHashTableSearch(table, str, length);

  if (indeks != -1) {
    printf("Çakışma var. ekleme yapılamadı çakışan indeks: %d \n", indeks);
    return;
  }

  if (table -> used == table -> size) {
    table -> size *= 2;
    table -> array = realloc(table -> array, table -> size * sizeof(int));
  }
  table -> array[table -> used++] = hash_result;

  resizeHashTable(table);

  #ifdef DEBUG
  printf("eklenen: %d , size : %d , used : %d \n", hash_result, table -> size, table -> used);
  #endif

}

int elfHashTableSearchSTR(HashTable * table, char * str, long length) {

  assert(strcmp("", str) != 0);
  assert(table != NULL);

  int hash_result = elfHash(str, length);

  for (int i = 0; i < table -> size; i++) {

    if (table -> array[i] == hash_result) {

      #ifdef DEBUG
      printf(" eleman bulundu.  indeks: %d \n", i);
      #endif

      return i;
    }

  }

  #ifdef DEBUG
  printf("eleman bulunamadı \n");
  #endif

  return -1;
}

int elfHashTableSearchINT(HashTable * table, int str, long length) {

  assert(table != NULL);

  int hash_result = elfHash(str, length);

  for (int i = 0; i < table -> size; i++) {

    if (table -> array[i] == hash_result) {

      #ifdef DEBUG
      printf(" eleman bulundu.  indeks: %d \n", i);
      #endif

      return i;
    }

  }
  #ifdef DEBUG
  printf("aynı hashe sahip eleman bulunamadı. \n");
  #endif

  return -1;
}

int elfHashTableSearchFLOAT(HashTable * table, float str, long length) {

  assert(table != NULL);

  int hash_result = elfHash(str, length);

  for (int i = 0; i < table -> size; i++) {

    if (table -> array[i] == hash_result) {

      #ifdef DEBUG
      printf(" eleman bulundu.  indeks: %d \n", i);
      #endif

      return i;
    }

  }
  #ifdef DEBUG
  printf("aynı hashe sahip eleman bulunamadı. \n");
  #endif

  return -1;
}

int elfHashTableSearchDOUBLE(HashTable * table, double str, long length) {

  assert(table != NULL);

  int hash_result = elfHash(str, length);

  for (int i = 0; i < table -> size; i++) {

    if (table -> array[i] == hash_result) {

      #ifdef DEBUG
      printf(" eleman bulundu.  indeks: %d \n", i);
      #endif

      return i;
    }

  }
  #ifdef DEBUG
  printf("aynı hashe sahip eleman bulunamadı. \n");
  #endif

  return -1;
}

int elfHashTableSearchLONGINT(HashTable * table, long int str, long length) {

  assert(table != NULL);

  int hash_result = elfHash(str, length);

  for (int i = 0; i < table -> size; i++) {

    if (table -> array[i] == hash_result) {

      #ifdef DEBUG
      printf(" eleman bulundu.  indeks: %d \n", i);
      #endif

      return i;
    }

  }
  #ifdef DEBUG
  printf("aynı hashe sahip eleman bulunamadı. \n");
  #endif

  return -1;
}

int elfHashTableSearchCUSTOM(HashTable * table, Elfnode * str, long length) {

  assert(table != NULL);

  int hash_result = elfHash(str, length);

  for (int i = 0; i < table -> size; i++) {

    if (table -> array[i] == hash_result) {

      #ifdef DEBUG
      printf(" eleman bulundu.  indeks: %d \n", i);
      #endif

      return i;
    }

  }
  #ifdef DEBUG
  printf("aynı hashe sahip eleman bulunamadı. \n");
  #endif

  return -1;
}

void printHashTable(HashTable * table) {


  #ifdef DEBUG
  assert(table != NULL);
  assert(table -> used > 0);
  #endif

  if(table== NULL){
    printf("hash table NULL.\n");
    return;
  }

  if (table -> used <= 0) {
    printf("hash table boş.\n");
    return;
  }

  for (int i = 0; i < table -> size; i++) {
    printf("%d. %d \n", i, table -> array[i]);
  }

}

void elfHashTableRemoveSTR(HashTable * table, char * str, long length) {
  assert(table != NULL);
  assert(strcmp("", str) != 0);

  int hash_result = elfHash(str, length);

  int indeks = elfHashTableSearch(table, str, length);

  if (indeks == -1) {
    printf("silinecek eleman dizide yok.\n");
    return;
  }

  for (int i = indeks; i < table -> size - 1; i++) {
    table -> array[i] = table -> array[i + 1];

  }

  table -> used--;
  resizeHashTable(table);

  printf("eleman silindi.\n");

}

void elfHashTableRemoveINT(HashTable * table, int str, long length) {
  assert(table != NULL);

  int hash_result = elfHash(str, length);

  int indeks = elfHashTableSearch(table, str, length);

  if (indeks == -1) {
    printf("silinecek eleman dizide yok.\n");
    return;
  }

  for (int i = indeks; i < table -> size - 1; i++) {
    table -> array[i] = table -> array[i + 1];

  }

  table -> used--;
  resizeHashTable(table);

  printf("eleman silindi.\n");

}

void elfHashTableRemoveFLOAT(HashTable * table, float str, long length) {
  assert(table != NULL);

  int hash_result = elfHash(str, length);

  int indeks = elfHashTableSearch(table, str, length);

  if (indeks == -1) {
    printf("silinecek eleman dizide yok.\n");
    return;
  }

  for (int i = indeks; i < table -> size - 1; i++) {
    table -> array[i] = table -> array[i + 1];

  }

  table -> used--;
  resizeHashTable(table);

  printf("eleman silindi.\n");

}

void elfHashTableRemoveDOUBLE(HashTable * table, double str, long length) {
  assert(table != NULL);

  int hash_result = elfHash(str, length);

  int indeks = elfHashTableSearch(table, str, length);

  if (indeks == -1) {
    printf("silinecek eleman dizide yok.\n");
    return;
  }

  for (int i = indeks; i < table -> size - 1; i++) {
    table -> array[i] = table -> array[i + 1];

  }

  table -> used--;
  resizeHashTable(table);

  printf("eleman silindi.\n");

}

void elfHashTableRemoveLONGINT(HashTable * table, long int str, long length) {
  assert(table != NULL);

  int hash_result = elfHash(str, length);

  int indeks = elfHashTableSearch(table, str, length);

  if (indeks == -1) {
    printf("silinecek eleman dizide yok.\n");
    return;
  }

  for (int i = indeks; i < table -> size - 1; i++) {
    table -> array[i] = table -> array[i + 1];

  }

  table -> used--;
  resizeHashTable(table);

  printf("eleman silindi.\n");

}

void elfHashTableRemoveCUSTOM(HashTable * table, Elfnode * str, long length) {
  assert(table != NULL);

  int hash_result = elfHash(str, length);

  int indeks = elfHashTableSearch(table, str, length);

  if (indeks == -1) {
    printf("silinecek eleman dizide yok.\n");
    return;
  }

  for (int i = indeks; i < table -> size - 1; i++) {
    table -> array[i] = table -> array[i + 1];

  }

  table -> used--;

  resizeHashTable(table);

  printf("eleman silindi.\n");

}

// hash table ın aldığı bellek alanını geri verir.
void freeHashTable(HashTable * a) {
  free(a -> array);
  a -> array = NULL;
  a -> used = a -> size = 0;
}

int errorMessage() {
  printf("Parametre tip uyusmazligi. islem tamamlanamadi \n");
  return -1;
}

Elfnode * create_node(char * data) {

  // ramden yer alma 
  Elfnode * node = (Elfnode * ) malloc(sizeof(Elfnode));

  node -> data = data; // veriyi ekleme
  node -> length = strlen(data); // uzunluğu atama
  printf("%d\n", elfHash(node, node -> length)); // hash sonucunu oluşturup ekleme. elfHash fonksiyonu kendisi node a sonucu yazar.

  return node;
}

// verilen girdi ile verilen  hashin uyuşup uyuşmadığını kontrol eden fonksiyon.
int checkHash(char * str1, int hash) {

  if (elfHash(str1, strlen(str1)) == hash) { // verilen metni hashle ve verilen hash ile kıyasla
    printf("\nhashler eslesiyor.\n");
    return basarili;
  } else {
    printf("\nhashler eslesmiyor.\n");
    return basarisiz;
  }

}