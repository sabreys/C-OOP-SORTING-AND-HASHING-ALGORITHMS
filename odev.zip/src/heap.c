#include <stdio.h>

#include"heap.h"

void swapINT(int * degisken1, int * degisken2) {

  int gecici = * degisken1;
  * degisken1 = * degisken2;
  * degisken2 = gecici;
}

void swapFLOAT(float * degisken1, float * degisken2) {
  float gecici = * degisken1;
  * degisken1 = * degisken2;
  * degisken2 = gecici;
}

void swapDOUBLE(double * degisken1, double * degisken2) {
  double gecici = * degisken1;
  * degisken1 = * degisken2;
  * degisken2 = gecici;
}

void swapCHAR(char * degisken1, char * degisken2) {
  char gecici = * degisken1;
  * degisken1 = * degisken2;
  * degisken2 = gecici;
}
void heapifyINT(int arr[], int n, int i) // arr[]' da bir indeks olan i dügümüne sahip bir alt agacý yiginlastirmak icin kullanilan integer fonksiyon. n, yigitin boyutudur.
{

  int enBuyuk = i; // En buyugunu kok olarak baslatilir.
  int sol = 2 * i + 1; // Sol = 2*i + 1 (Sol agacin hesaplama formulu)
  int sag = 2 * i + 2; // Sað = 2*i + 2 (Sol agacin hesaplama formulu)

  // Sol cocuk kokten buyukse.
  if (sol < n && arr[sol] > arr[enBuyuk])
    enBuyuk = sol;

  // Sag cocuk suana kadar ki en buyuk olandan buyukse.
  if (sag < n && arr[sag] > arr[enBuyuk])
    enBuyuk = sag;

  // En buyugu kok degilse
  if (enBuyuk != i) {
    swapPair( & arr[i], & arr[enBuyuk]);

    heapify(arr, n, enBuyuk); // Etkilenen alt agaci ozyinelemeli olarak yiginlayan kod parcasi.
  }
}

void heapifyFLOAT(float arr[], int n, int i) // arr[]' da bir indeks olan i dugumune sahip bir alt agaci yiginlastirmak icin kullanilan float tipindeki fonksiyon. n, yigin boyutudur.
{

  int enBuyuk = i; // En buyugunu kok olarak baslatilir.
  int sol = 2 * i + 1; // Sol = 2*i + 1 (Sol agacin hesaplama formulu)
  int sag = 2 * i + 2; // Sað = 2*i + 2 (Sol agacin hesaplama formulu)

  // Sol cocuk kokten buyukse.
  if (sol < n && arr[sol] > arr[enBuyuk])
    enBuyuk = sol;

  // Sag cocuk suana kadar ki en buyuk olandan buyukse.
  if (sag < n && arr[sag] > arr[enBuyuk])
    enBuyuk = sag;

  // En buyugu kok degilse
  if (enBuyuk != i) {
    swapPair( & arr[i], & arr[enBuyuk]);

    heapify(arr, n, enBuyuk); // Etkilenen alt agaci ozyinelemeli olarak yiginlayan kod parcasi.
  }
}

void heapifyDOUBLE(double arr[], int n, int i) // arr[]' da bir indeks olan i dügümüne sahip bir alt agacý yiginlastirmak icin kullanilan double tipindeki fonksiyon. n, yigitin boyutudur.
{

  int enBuyuk = i; // En buyugunu kok olarak baslatilir.
  int sol = 2 * i + 1; // Sol = 2*i + 1 (Sol agacin hesaplama formulu)
  int sag = 2 * i + 2; // Sað = 2*i + 2 (Sol agacin hesaplama formulu)

  // Sol cocuk kokten buyukse.
  if (sol < n && arr[sol] > arr[enBuyuk])
    enBuyuk = sol;

  // Sag cocuk suana kadar ki en buyuk olandan buyukse.
  if (sag < n && arr[sag] > arr[enBuyuk])
    enBuyuk = sag;

  // En buyugu kok degilse
  if (enBuyuk != i) {
    swapPair( & arr[i], & arr[enBuyuk]);

    heapify(arr, n, enBuyuk); // Etkilenen alt agaci ozyinelemeli olarak yiginlayan kod parcasi.
  }
}

void heapifyCHAR(char arr[], int n, int i) // arr[]' da bir indeks olan i dügümüne sahip bir alt agacý yiginlastirmak icin kullanilan char tipindeki fonksiyon. n, yigitin boyutudur.
{

  int enBuyuk = i; // En buyugunu kok olarak baslatilir.
  int sol = 2 * i + 1; // Sol = 2*i + 1 (Sol agacin hesaplama formulu)
  int sag = 2 * i + 2; // Sað = 2*i + 2 (Sol agacin hesaplama formulu)

  // Sol cocuk kokten buyukse.
  if (sol < n && arr[sol] > arr[enBuyuk])
    enBuyuk = sol;

  // Sag cocuk suana kadar ki en buyuk olandan buyukse.
  if (sag < n && arr[sag] > arr[enBuyuk])
    enBuyuk = sag;

  // En buyugu kok degilse
  if (enBuyuk != i) {
    swapPair( & arr[i], & arr[enBuyuk]);

    heapify(arr, n, enBuyuk); // Etkilenen alt agaci ozyinelemeli olarak yiginlayan kod parcasi.
  }
}

// Yigin siralama yapabilmek icin integer tipindeki ana fonksiyon.
void heapSortINT(int arr[], int n) {

  if(n == 0 ){
    printf("array boş.\n");
  }

  // Yigin olusturun. (diziyi yeniden duzenleyin)
  for (int i = n / 2 - 1; i >= 0; i--)
    heapifyINT(arr, n, i);

  // Yigindan bir ogeyi tek tek ayiklayin.
  for (int i = n - 1; i > 0; i--) {
    // Mevcut koku sona tasi
    swapPair( & arr[0], & arr[i]);

    // Kucultulmus yiginin icinde maksimum yigini cagir.
    heapifyINT(arr, i, 0);
  }
}

// Yigin siralama yapabilmek icin float tipindeki ana fonksiyon.
void heapSortFLOAT(float arr[], int n) {
  if(n == 0 ){
    printf("array boş.\n");
  }

  // Yigin olusturun. (diziyi yeniden duzenleyin)
  for (int i = n / 2 - 1; i >= 0; i--)
    heapify(arr, n, i);

  // Yigindan bir ogeyi tek tek ayiklayin.
  for (int i = n - 1; i > 0; i--) {
    // Mevcut koku sona tasi
    swapPair( & arr[0], & arr[i]);

    // Kucultulmus yiginin icinde maksimum yigini cagir.
    heapify(arr, i, 0);
  }
}

// Yigin siralama yapabilmek icin double tipindeki ana fonksiyon.
void heapSortDOUBLE(double arr[], int n) {
  if(n == 0 ){
    printf("array boş.\n");
  }

  // Yigin olusturun. (diziyi yeniden duzenleyin)
  for (int i = n / 2 - 1; i >= 0; i--)
    heapify(arr, n, i);

  // Yigindan bir ogeyi tek tek ayiklayin.
  for (int i = n - 1; i > 0; i--) {
    // Mevcut koku sona tasi
    swapPair( & arr[0], & arr[i]);

    // Kucultulmus yiginin icinde maksimum yigini cagir.
    heapify(arr, i, 0);
  }
}

// Yigin siralama yapabilmek icin char tipindeki ana fonksiyon.
void heapSortCHAR(char arr[], int n) {
  if(n == 0 ){
    printf("array boş.\n");
  }

  // Yigin olusturun. (diziyi yeniden duzenleyin)
  for (int i = n / 2 - 1; i >= 0; i--)
    heapify(arr, n, i);

  // Yigindan bir ogeyi tek tek ayiklayin.
  for (int i = n - 1; i > 0; i--) {
    // Mevcut koku sona tasi
    swapPair( & arr[0], & arr[i]);

    // Kucultulmus yiginin icinde maksimum yigini cagir.
    heapify(arr, i, 0);
  }
}

/* n boyutunda diziyi yazdirmak icin char tipinde bir yardimci program islevi */
void printCharArray(char girdi[], int boyut) {
  for (int i = 0; i < boyut; i++) {
    printf("%c,", girdi[i]);
  }
  printf("\n");
}

/* n boyutunda diziyi yazdirmak icin int tipinde bir yardimci program islevi */
void printIntArray(int girdi[], int boyut) {
  for (int i = 0; i < boyut; i++) {
    printf("%d,", girdi[i]);
  }
  printf("\n");
}

/* n boyutunda diziyi yazdirmak icin float tipinde bir yardimci program islevi */
void printArrayFLOAT(float girdi[], int boyut) {
  for (int i = 0; i < boyut; i++) {
    printf("%f,", girdi[i]);
  }
  printf("\n");
}

/* n boyutunda diziyi yazdirmak icin double tipinde bir yardimci program islevi */
void printArrayDOUBLE(double girdi[], int boyut) {
  for (int i = 0; i < boyut; i++) {
    printf("%lf,", girdi[i]);
  }
  printf("\n");
}

// Hata mesajlari
int errorMessageHEAPIFY() {
  printf("heapify tip hatasi\n");
  return -1;
}
int errorMessageHEAPSORT() {
  printf("heapsort tip hatasi\n");
  return -1;
}
int errorMessageSWAP() {
  printf("swap tip hatasi\n");
  return -1;
}

int errorMessages() {
  printf("hata");
  return -1;
}
