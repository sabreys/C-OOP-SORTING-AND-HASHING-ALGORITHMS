 #include "xorll.h"

 #include <stdio.h>

 #include <string.h>

 #include <stdlib.h>

 #include <stdint.h>

 //XOR hesaplama fonksiyon */
 node_ll * XOR(node_ll * a, node_ll * b) {

   return (node_ll * )((uintptr_t)(a) ^ (uintptr_t)(b));
 }

 node_ll * initINT(int data) {
   // yeni node için bellek tutuyoruz

   int * temp = (int * ) malloc(sizeof(int));

   * temp = data;

   node_ll * new = (node_ll * ) malloc(sizeof(node_ll));
   new -> data = (int * ) temp;

   new -> type = intll;

   // Listede ilk ve tek node olacağından önceki ve sonraki node NULL
   new -> npx = XOR(NULL, NULL);
   return new;
 }

 node_ll * initFLOAT(float data) {

   float * temp = (float * ) malloc(sizeof(float));

   * temp = data;

   // yeni node için bellek tutuyoruz
   node_ll * new = (node_ll * ) malloc(sizeof(node_ll));

   new -> data = (float * ) temp;

   new -> type = floatll;
   // Listede ilk ve tek node olacağından önceki ve sonraki node NULL
   new -> npx = XOR(NULL, NULL);
   return new;
 }

 node_ll * initCHAR(char data) {

   char * temp = (char * ) malloc(sizeof(char));

   * temp = data;
   // yeni node için bellek tutuyoruz
   node_ll * new = (node_ll * ) malloc(sizeof(node_ll));

   new -> data = (char * ) temp;
   new -> type = charll;
   // Listede ilk ve tek node olacağından önceki ve sonraki node NULL
   new -> npx = XOR(NULL, NULL);
   return new;
 }

 node_ll * initDOUBLE(double data) {

   double * temp = (double * ) malloc(sizeof(double));

   * temp = data;
   // yeni node için bellek tutuyoruz
   node_ll * new = (node_ll * ) malloc(sizeof(node_ll));

   new -> data = (double * ) temp;

   new -> type = doublell;

   // Listede ilk ve tek node olacağından önceki ve sonraki node NULL
   new -> npx = XOR(NULL, NULL);
   return new;
 }

 void ekleINT(node_ll ** head, int data) {

   #ifdef DEBUG
   assert( * head != NULL);
   #endif

   if ( * head == NULL) {
     printf("verilen liste boş. Yeni liste oluşturuluyor.\n");
     * head = init(data);

     return;
   }

   //headın adresi tutacak
   node_ll * curr = * head;

   int * temp = (int * ) malloc(sizeof(int));

   * temp = data;

   // yeni node için bellek tutuyoruz
   node_ll * node = (node_ll * ) malloc(sizeof(node_ll));
   // headın XOR değiştiriyoruz  
   curr -> npx = XOR(node, XOR(NULL, curr -> npx)); //2. XOR curr node sonraki adresi verir
   // new node XOR oluşturuyoruz
   node -> npx = XOR(NULL, curr);

   node -> type = intll;

   // new node head olarak kaydediyoruz
   * head = node;

   //datayı kaydediyoruz
   node -> data = (int * ) temp;

 }

 void ekleFLOAT(node_ll ** head, float data) {

   #ifdef DEBUG
   assert( * head != NULL);
   #endif

   if ( * head == NULL) {
     printf("verilen liste boş. Yeni liste oluşturuluyor.\n");
     * head = init(data);
     return;
   }

   //headın adresi tutacak
   node_ll * curr = * head;

   float * temp = (float * ) malloc(sizeof(float));

   * temp = data;

   // yeni node için bellek tutuyoruz
   node_ll * node = (node_ll * ) malloc(sizeof(node_ll));
   // headın XOR değiştiriyoruz  
   curr -> npx = XOR(node, XOR(NULL, curr -> npx)); //2. XOR curr node sonraki adresi verir
   // new node XOR oluşturuyoruz
   node -> npx = XOR(NULL, curr);

   node -> type = floatll;

   * head = node;

   //datayı kaydediyoruz
   node -> data = (float * ) temp;
 }

 void ekleCHAR(node_ll ** head, char data) {

   #ifdef DEBUG
   assert( * head != NULL);
   #endif

   if ( * head == NULL) {
     printf("verilen liste boş. Yeni liste oluşturuluyor.\n");
     * head = init(data);
     return;
   }

   //headın adresi tutacak
   node_ll * curr = * head;

   char * temp = (char * ) malloc(sizeof(char));

   * temp = data;

   // yeni node için bellek tutuyoruz
   node_ll * node = (node_ll * ) malloc(sizeof(node_ll));
   // headın XOR değiştiriyoruz  
   curr -> npx = XOR(node, XOR(NULL, curr -> npx)); //2. XOR curr node sonraki adresi verir
   // new node XOR oluşturuyoruz
   node -> npx = XOR(NULL, curr);

   node -> type = charll;
   // new node head olarak kaydediyoruz
   * head = node;

   //datayı kaydediyoruz
   node -> data = (char * ) temp;
 }

 void ekleDOUBLE(node_ll ** head, double data) {

   #ifdef DEBUG
   assert( * head != NULL);
   #endif

   if ( * head == NULL) {
     printf("verilen liste boş. Yeni liste oluşturuluyor.\n");
     * head = init(data);
     return;
   }

   //headın adresi tutacak
   node_ll * curr = * head;

   double * temp = (double * ) malloc(sizeof(double));

   * temp = data;

   // yeni node için bellek tutuyoruz
   node_ll * node = (node_ll * ) malloc(sizeof(node_ll));
   // headın XOR değiştiriyoruz  
   curr -> npx = XOR(node, XOR(NULL, curr -> npx)); //2. XOR curr node sonraki adresi verir
   // new node XOR oluşturuyoruz
   node -> npx = XOR(NULL, curr);

   node -> type = doublell;

   // new node head olarak kaydediyoruz
   * head = node;

   //datayı kaydediyoruz
   node -> data = (double * ) temp;
 }

 // XOR linked list yazdirma fonksiyonu(sagdan sola)
 void yazdirList(node_ll * head) {

   node_ll * curr = head;
   node_ll * prev = NULL;
   node_ll * next;

   printf("Nodes of Linked List: \n");
   while (curr != NULL) {
     // suan bulundugumuz node yazdiriyoruz

     switch (curr -> type) {

     case intll:

       printf("%d ", *(int * ) curr -> data);
       break;

     case floatll:

       printf("%f ", *(float * ) curr -> data);

       break;

     case charll:

       printf("%c ", *(char * ) curr -> data);
       break;

     case doublell:

       printf("%f ", *(double * ) curr -> data);

       break;

     }

     // next node icin adresi bulacagiz : (curr->npx)=(next^prev),
     // o zaman (curr->npx^prev)=(next^prev^prev) next olacak
     next = XOR(prev, curr -> npx);

     // sonraki adim icin prev ve curr guncelliyoruz
     prev = curr;
     curr = next;
   }

   if (prev == NULL && prev == NULL) {
     printf("Dizi boş \n");
   }

   printf("\n");

 }

 void max(node_ll * head) {

   #ifdef DEBUG
   assert(head != NULL);
   #endif

   if (head == NULL) {
     printf("head NULL !\n");
     return;
   }

   node_ll * curr = head;
   node_ll * prev = NULL;
   node_ll * next;

   double holder;

   int type;

   switch (head -> type) {

   case intll:
     holder = (double) * (int * ) head -> data;
     break;
   case floatll:
     holder = (double)( * (float * ) head -> data);
     break;
   case charll:
     holder = (double) * (char * ) head -> data;
     break;
   case doublell:
     holder = (double)( * (double * ) head -> data);
   }

   while (curr != NULL) {

     switch (curr -> type) {

     case intll:

       if (holder < ( * (int * ) curr -> data)) {
         holder = ( * (int * ) curr -> data);
         type = intll;

       }

       break;

     case floatll:

       if (holder < * (float * ) curr -> data) {
         holder = * (float * ) curr -> data;
         type = floatll;
       }

       break;

     case charll:

       if (holder < ( * (char * ) curr -> data)) {
         holder = ( * (char * ) curr -> data);
         type = charll;
       }

       break;

     case doublell:

       if (holder < * (double * ) curr -> data) {
         holder = * (double * ) curr -> data;
         type = doublell;
       }

       break;

     }

     // next node icin adresi bulacagiz : (curr->npx)=(next^prev),
     // o zaman (curr->npx^prev)=(next^prev^prev) next olacak
     next = XOR(prev, curr -> npx);
     // sonraki adim icin prev ve curr guncelliyoruz
     prev = curr;
     curr = next;

   }

   switch (type) {

   case intll:
     printf("Max data is : %d \n", (int) holder);
     break;
   case floatll:
     printf("Max data is : %f \n", holder);
     break;
   case charll:
     printf("Max data is : %c \n", (int) holder);
     break;
   case doublell:
     printf("Max data is : %f \n", holder);

   default:
     printf("Max data is : %f \n", holder);
   }

 }

 void min(node_ll * head) {

   #ifdef DEBUG
   assert(head != NULL);
   #endif

   if (head == NULL) {
     printf("head NULL !\n");
     return;
   }

   node_ll * curr = head;
   node_ll * prev = NULL;
   node_ll * next;

   double holder;

   int type;

   switch (head -> type) {

   case intll:
     holder = (double) * (int * ) head -> data;
     break;
   case floatll:
     holder = (double)( * (float * ) head -> data);
     break;
   case charll:
     holder = (double) * (char * ) head -> data;
     break;
   case doublell:
     holder = (double)( * (double * ) head -> data);
   }

   while (curr != NULL) {

     switch (curr -> type) {

     case intll:

       if (holder > ( * (int * ) curr -> data)) {
         holder = ( * (int * ) curr -> data);
         type = intll;

       }

       break;

     case floatll:

       if (holder > * (float * ) curr -> data) {
         holder = * (float * ) curr -> data;
         type = floatll;
       }

       break;

     case charll:

       if (holder > ( * (char * ) curr -> data)) {
         holder = ( * (char * ) curr -> data);
         type = charll;
       }

       break;

     case doublell:

       if (holder > * (double * ) curr -> data) {
         holder = * (double * ) curr -> data;
         type = doublell;
       }

       break;

     }

     // next node icin adresi bulacagiz : (curr->npx)=(next^prev),
     // o zaman (curr->npx^prev)=(next^prev^prev) next olacak
     next = XOR(prev, curr -> npx);
     // sonraki adim icin prev ve curr guncelliyoruz
     prev = curr;
     curr = next;

   }

   switch (type) {

   case intll:
     printf("Min data is : %f \n", holder);
     break;
   case floatll:
     printf("Min data is : %f \n", holder);
     break;
   case charll:
     printf("Min data is : %c \n", (int) holder);
     break;
   case doublell:
     printf("Min data is : %f \n", holder);

   default:
     printf("Min data is : %f \n", holder);
   }

 }

 void delEnd(node_ll ** head) {
   #ifdef DEBUG
   assert(head != NULL);
   #endif

   if (head == NULL) {
     printf("head NULL !\n");
     return;
   }

   if ( * head == NULL)
     printf("Liste boş.\n"); //xorll boş ise yazdırsın

   else {
     //headın adresi
     node_ll * curr = * head;
     // önceki node adresi
     node_ll * prev = NULL;
     //sonraki node adresi
     node_ll * next;
     //son uç node bulmak için oluşturduğumuz while döngüsü
     while (XOR(curr -> npx, prev) != NULL) { //next node NULL mu değil mi bakmaktadir
       // next buluyoruz
       next = XOR(prev, curr -> npx);
       // prev ve curr nodeleri güncelliyoruz
       prev = curr;
       curr = next;
     }
     //eğer listede 1'den fazla node varsa
     if (prev != NULL)
       prev -> npx = XOR(XOR(prev -> npx, curr), NULL);
     else
       *head = NULL;

     // son node bellekten siliyoruz
     free(curr);
     printf("Son node silindi!\n");
   }
 }

 int typeError() {
   printf("tip hatası. NUll yada uyumsuz veri tipi\n");
   return -1;
 }