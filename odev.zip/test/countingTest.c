#include <stdio.h>

#include <string.h>

#include <time.h>

#include "counting.h"


/* Counting Sort kütüphanesini denemek amaçlı test programı
 * farklı tipte verileri vererek sonuçlarını yazdırır.
 * 12.grup Programlamada özel konular dersi ödevi. 2021 yaz.
 * 
 */

void worstCase_test() {
  clock_t begin = clock();

  double char_time, int_time, longlong_int_time, unsigned_time, long_int_time, short_time, model_time;

  char arr[] = "zyxwvutsrqponmlkjihgfedcba";
  int arr1[] = {
    9,
    8,
    7,
    6,
    5,
    4,
    3,
    2,
    1
  };
  long long int arr2[] = {
    99999,
    88888,
    77777,
    66666,
    55555,
    44444,
    33333,
    22222,
    11111
  }; // stack üzerinde tutulan veri  6 basamaktan büyük sayılarda segmentation fault hatası veriyor. bu sebeple dinamik yer alma denendi.
  //  counting sort max sayı uzunluğunda bir dizi oluşturduğu için long long int stack üzerinde alan sorunu yaşıyor. 6 basamak sonrasında çalışma sorunu oluşuyor. dinamik yer alma denendi fakat
  // çalıştırılamadı.
  unsigned int arr3[] = {
    90,
    80,
    70,
    60,
    50,
    40,
    30,
    20,
    10
  };

  long int arr4[] = {
    99999,
    88888,
    77777,
    66666,
    55555,
    44444,
    33333,
    22222,
    11111
  };
  short int arr5[] = {
    9,
    8,
    7,
    6,
    5,
    4,
    3,
    2,
    1
  };
  CustomModel * modelim = createModel(arr1, findRange(arr1, 9), 9, intModel); // arr1 dizisinin verisini içeren intModeli.

  begin = clock();
  countingSort(arr, 26);
  clock_t end = clock();
  char_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  begin = clock();
  countingSort(arr1, 9);
  end = clock();
  int_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  begin = clock();
  countingSort(arr2, 9);
  end = clock();
  longlong_int_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  begin = clock();
  countingSort(arr3, 9);
  end = clock();
  unsigned_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  begin = clock();
  countingSort(arr4, 9);
  end = clock();
  long_int_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  begin = clock();
  countingSort(arr5, 9);
  end = clock();
  short_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  printf("----------\n");
  printf("Wost Case run time :\n");

  begin = clock();

  countingSort(modelim, modelim -> size);
  end = clock();
  model_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  printf("\nSıralama Sonrası veriler:\n");
  printArray(arr, 26); // char  tipi aldı.
  printArray(arr1, 9); // int tipi aldı.
  printArray(arr2, 9); // long long int  tipi aldı.
  printArray(arr3, 9); // unsigned int  tipi aldı.
  printArray(arr4, 9); // long int  tipi aldı.
  printArray(arr5, 9); //short int  tipi aldı.
  printArray(modelim, modelim -> size); // customModel tipi aldı.

  //,,,,

  printf("char tip worst case run time : %lf \n", char_time);
  printf("int tip worst case run time : %lf \n", int_time);
  printf("long long int tip worst case run time : %lf \n", longlong_int_time);
  printf("unsigned int tip worst case run time : %lf \n", unsigned_time);
  printf("long int tip worst case run time : %lf \n", long_int_time);
  printf("short int tip worst case run time : %lf \n", short_time);
  printf("model tip worst case run time : %lf \n", model_time);

}

void bestCase_test() {
  printf("----------\n");
  printf("Best Case run time :\n");
  clock_t begin = clock();

  double char_time, int_time, longlong_int_time, unsigned_time, long_int_time, short_time, model_time;

  char arr[] = "abcdefghijklmnopqrstuvwxyz";
  int arr1[] = {
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9
  };
  long long int arr2[] = {
    11111,
    22222,
    33333,
    44444,
    55555,
    66666,
    77777,
    88888,
    99999
  }; // stack üzerinde tutulan veri  6 basamaktan büyük sayılarda segmentation fault hatası veriyor. bu sebeple dinamik yer alma denendi.
  //  counting sort max sayı uzunluğunda bir dizi oluşturduğu için long long int stack üzerinde alan sorunu yaşıyor. 6 basamak sonrasında çalışma sorunu oluşuyor. dinamik yer alma denendi fakat
  // çalıştırılamadı.
  unsigned int arr3[] = {
    10,
    20,
    30,
    40,
    50,
    60,
    70,
    80,
    90
  };

  long int arr4[] = {
    11111,
    22222,
    33333,
    44444,
    55555,
    66666,
    77777,
    88888,
    99999
  };
  short int arr5[] = {
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9
  };
  CustomModel * modelim = createModel(arr1, findRange(arr1, 9), 9, intModel); // arr1 dizisinin verisini içeren intModeli.

  begin = clock();
  countingSort(arr, 26);
  clock_t end = clock();
  char_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  begin = clock();
  countingSort(arr1, 9);
  end = clock();
  int_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  begin = clock();
  countingSort(arr2, 9);
  end = clock();
  longlong_int_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  begin = clock();
  countingSort(arr3, 9);
  end = clock();
  unsigned_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  begin = clock();
  countingSort(arr4, 9);
  end = clock();
  long_int_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  begin = clock();
  countingSort(arr5, 9);
  end = clock();
  short_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  begin = clock();

  countingSort(modelim, modelim -> size);
  end = clock();
  model_time = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  printf("\nSıralama Sonrası veriler:\n");
  printArray(arr, 26); // char  tipi aldı.
  printArray(arr1, 9); // int tipi aldı.
  printArray(arr2, 9); // long long int  tipi aldı.
  printArray(arr3, 9); // unsigned int  tipi aldı.
  printArray(arr4, 9); // long int  tipi aldı.
  printArray(arr5, 9); //short int  tipi aldı.
  printArray(modelim, modelim -> size); // customModel tipi aldı.

  //,,,,

  printf("char tip worst case run time : %lf \n", char_time);
  printf("int tip worst case run time : %lf \n", int_time);
  printf("long long int tip worst case run time : %lf \n", longlong_int_time);
  printf("unsigned int tip worst case run time : %lf \n", unsigned_time);
  printf("long int tip worst case run time : %lf \n", long_int_time);
  printf("short int tip worst case run time : %lf \n", short_time);
  printf("model tip worst case run time : %lf \n", model_time);

}

void empty_array_test(){
  printf("----------\n");
  printf("Boş dizi testi:\n");
  clock_t begin = clock();

  double char_time, int_time, longlong_int_time, unsigned_time, long_int_time, short_time, model_time;

  char arr[] = "";

   int arr1[] = {} ;

  long long int arr2[]={} ;

    countingSort(arr, 0);
    countingSort(arr1, 0);
    countingSort(arr2, 0);

    printArray(arr, 0); 
    printArray(arr1, 0); 
    printArray(arr2, 0); 

}


// null arraylerde test
void null_element_test(){
 printf("----------\n");
  printf("Null dizi testi(tip hatası vermeli):\n");

    countingSort(NULL, 0);
    printArray(NULL, 0); 

}


// büyük boyutlu bir dizi ile test işlemi
void huge_array_test(){
  printf("----------\n");
  printf("Yüksek boyutlu dizi testi :\n");

    

  int arr[] = {11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,
    11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,
    11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,
    11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,
    11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,
    11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,
    11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,
    11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,11111,22222,33333,44444,55555,66666,77777,88888,99999,
    11111,22222,33333,44444,55555,66666,77777,88888,99999};

 

  clock_t begin = clock();
  countingSort(arr, 360);
  clock_t end = clock();
  double runtime = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;

  printf("süre:%f\n",runtime); 

  printArray(arr, 360); 

}



void standart_verilerle_test() {
  printf("Standart veriler ile test başlıyor...\n");
  // örnek veri kümeleri.
  char arr[] = "test metni";
  int arr1[] = {
    1,
    200,
    3,
    4,
    78
  };
  long long int arr2[] = {
    111111,
    2544,
    11451,
    94459,
    1561,
    1226,
    41232
  }; // stack üzerinde tutulan veri  6 basamaktan büyük sayılarda segmentation fault hatası veriyor. bu sebeple dinamik yer alma denendi.
  //  counting sort max sayı uzunluğunda bir dizi oluşturduğu için long long int stack üzerinde alan sorunu yaşıyor. 6 basamak sonrasında çalışma sorunu oluşuyor. dinamik yer alma denendi fakat
  // çalıştırılamadı.
  unsigned int arr3[] = {
    43,
    12,
    2,
    65,
    34
  };
  long int arr4[] = {
    123234,
    23425,
    11111,
    999999
  };
  short int arr5[] = {
    1,
    70,
    34,
    76,
    9,
    55
  };
  CustomModel * modelim = createModel(arr1, findRange(arr1, 5), 5, intModel); // arr1 dizisinin verisini içeren intModeli.
  CustomModel * modelim2 = createModel(arr2, findRange(arr2, 3), 3, longLongModel);

  //verileri yazdır

  printf("Veriler:\n");
  printArray(arr, 10); // char  tipi aldı.
  printArray(arr1, 5); // int tipi aldı.
  printArray(arr2, 3); // long long int  tipi aldı.
  printArray(arr3, 5); // unsigned int  tipi aldı.
  printArray(arr4, 4); // long int  tipi aldı.
  printArray(arr5, 6); //short int  tipi aldı.
  printArray(modelim, 5); // customModel tipi aldı.
  printArray(modelim2, 3);

  printf("\nSıralama İşlemi başlatılıyor \n");

  countingSort(arr, 10);
  countingSort(arr1, 5);
  countingSort(arr2, 3);
  countingSort(arr3, 5);
  countingSort(arr4, 4);
  countingSort(arr5, 6);
  countingSort(modelim, modelim -> size);
  countingSort(modelim2, modelim2 -> size);

  printf("\nSıralama Sonrası veriler:\n");
  printArray(arr, 10); // char  tipi aldı.
  printArray(arr1, 5); // int tipi aldı.
  printArray(arr2, 3); // long long int  tipi aldı.
  printArray(arr3, 5); // unsigned int  tipi aldı.
  printArray(arr4, 4); // long int  tipi aldı.
  printArray(arr5, 6); //short int  tipi aldı.
  printArray(modelim, modelim -> size); // customModel tipi aldı.
  printArray(modelim2, modelim2 -> size);
  
}

int main() {
  standart_verilerle_test();
  worstCase_test();
  bestCase_test();
  empty_array_test();
  null_element_test();
  huge_array_test();

  return 0;
}