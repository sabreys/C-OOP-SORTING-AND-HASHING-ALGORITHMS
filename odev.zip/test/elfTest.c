#include <stdio.h>

#include <string.h>

#include "elf.h"


/* Elf Hash kütüphanesini denemek amaçlı test programı
 * farklı tipte verileri vererek sonuçlarını yazdırır.
 * parametre olarak da veri alıp hashleyebilir.
 * kullanım: test "metin"
 * eğer parametre verilirse verilen veriyi hashler. yoksa örnek verileri işler.
 *  
 */

// standart tipler ile hash fonksiyonlarının çalışmasını kontrol eder.
void standart_degerlerle_test() {

  printf("---------\n");
  printf("Standart verilerle hash testi başlatılıyor...\n");

  HashTable table;
  float b = 2.55;
  long int c = 1234123412341234;
  double d = 2.11;

  printf("Node yaratma ve hashleme :\n");
  Elfnode * test_node1 = create_node("node yaratma denemesi");
  printf("%d\n", test_node1 -> hash_result);
  printf("---------\n");
  Elfnode * test_node2 = (Elfnode * ) malloc(sizeof(Elfnode));
  test_node2 -> data = "bu bir node verisidir.";
  test_node2 -> length = strlen(test_node2 -> data);

  printf("Farklı veri tiplerinde kullanımı:\n");

  printf("%d\n", elfHash(2222, 4));

  printf("%d\n", elfHash(b, 4));

  printf("%d \n", elfHash(c, 16));

  printf("%d \n", elfHash(d, 4));

  printf("%d \n", elfHash(test_node2, test_node2 -> length));

  printf("---------\n");

  printf("Hash Tablosu oluşturma(assert alınmadığı durumda başarılı)\n");

  printf("initializing işlemi yapılıyor.\n");
  initHashTable( & table, 1); //ilk boyut 1 verildi
  printf("farklı tipte elemanlar ekleniyor.\n");
  elfHashTableAdd( & table, "deneme1", 7); //Hash tablosu float, int, string ve diğer tipleri aynı anda tutabilmektedir çünkü hepsinin hash sonucu inttir.
  elfHashTableAdd( & table, 1, 1);
  elfHashTableAdd( & table, 1.3, 3);
  elfHashTableAdd( & table, test_node2, test_node2 -> length);
  elfHashTableAdd( & table, c, 16);

  printHashTable( & table);

  printf("1 Eleman silme işlemi : \n");
  elfHashTableRemove( & table, 1.3, 3);
  printHashTable( & table);

  printf("Olmayan elemanı silme: \n");
  elfHashTableRemove( & table, 1.3, 3);

  printf("Tüm elemanları silme \n");

  elfHashTableRemove( & table, 1, 1);
  printHashTable( & table);

  elfHashTableRemove( & table, "deneme1", 7); //Hash tablosu float, int, string ve diğer tipleri aynı anda tutabilmektedir çünkü hepsinin hash sonucu inttir.
  printHashTable( & table);

  elfHashTableRemove( & table, test_node2, test_node2 -> length);
  printHashTable( & table);
  elfHashTableRemove( & table, c, 16);

  printHashTable( & table);
  printf("---------\n");

  printf("Hash kıyaslama :\n");

  printf("dogru veri:");
  int res1 = checkHash("bu bir node verisidir.", test_node2 -> hash_result);
  printf("yanlış veri:");
  int res2 = checkHash("bu bir node verisi değildir", test_node2 -> hash_result);

  if (res1 == basarili && res2 == basarisiz) {
    printf("Hata bulunamadı test başarılı.\n");

    return;
  } else {

    printf("Hash kıyaslamada hata var. doğru kıyas yapılamadı.\n");
  }

}

// otomatik boyut tayini amacıyla kullanılır
int sizeOfInt(int sayi) {
  int count = 1;
  while (sayi != 0) {
    sayi /= 10;
    ++count;
  }

  return count;
}

void bos_HashTable_test() {
  printf("---------\n");
  printf("NULL hash table testi başlatılıyor...\n \n");

  initHashTable(NULL, 5); //ilk boyut 5 verildi


}


void bos_string_test() {
  printf("---------\n");
  printf("Boş String hash table testi başlatılıyor...\n ");
  HashTable a;

  initHashTable( & a, 1);

  elfHashTableAdd( & a, "", 0);
  printHashTable( & a);


}

// aynı iki stringin hash değerlerini eklemeye çalışma durumunda hata mesajı yazar ve elemanı eklemez.
void string_cakisma_test() {
  printf("---------\n");
  printf("String Çakışma testi başlatılıyor\n");
  HashTable a;

  initHashTable( & a, 1);
  printf("\n");
  elfHashTableAdd( & a, "ab", 2);

  elfHashTableAdd( & a, "ab", 2);

  if (a.size > 1) {
    printf("basarısız.\n");
  }
  printf("başarılı.\n");

}

// int değerler ile çakışma testi. aynı elemanın eklenmeye çalışması durumudur.
void int_cakisma_test() {
  printf("---------\n");
  printf("İnt Çakışma testi başlatılıyor(çakışma bulunup elemanın eklenmemesi gerekir.)\n");
  HashTable a;

  initHashTable( & a, 1); //ilk boyut 1 verildi

  elfHashTableAdd( & a, 153, 3);

  elfHashTableAdd( & a, 153, 3);

  if (a.size > 1) { //  resizeble array oldugu için eğer ekleme olursa boyutu büyüyecektir.
    printf("basarısız.\n");
  }
  printf("başarılı.\n");

}


void double_cakisma_test() {
  printf("---------\n");
  printf("Double Çakışma testi başlatılıyor(çakışma bulunup elemanın eklenmemesi gerekir.)\n");
  HashTable a;

  initHashTable( & a, 1); //ilk boyut 1 verildi

  elfHashTableAdd( & a, 1.3, 3);

  elfHashTableAdd( & a, 1.3, 3);

  if (a.size > 1) { //  resizeble array oldugu için eğer ekleme olursa boyutu büyüyecektir.
    printf("basarısız.\n");
  }
  printf("başarılı.\n");

}


// 1000 adet veri yükler. resize ve çakışma durumunu test için kullanılır. çakışma durumunda assert vermesi beklenir.
void yukleme_testi() {
  printf("---------\n");
  printf("yükleme testi başlatılıyor. (bin veri eklenerek herhangi bir hash çakışması olup olmadığı izlenir.)DEBUG modeda assert verir\n");

  HashTable a;

  initHashTable( & a, 5); //ilk boyut 5 verildi

  for (int i = 0; i < 1000; i++) {

    elfHashTableAdd( & a, i, sizeOfInt(i));

  }

  printf("Yükleme testi başarılı.\n");

}

// farklı tiplerede sahip olsa aynı içeriğin arama sonucunda bulunma testi
void arama_testi() {
  printf("---------\n");

  printf("Arama testi başlatılıyor...\n");
  HashTable a;

  initHashTable( & a, 5); //ilk boyut 5 verildi

  elfHashTableAdd( & a, 1.1, 3);
  elfHashTableAdd( & a, 3.5, 3);
  elfHashTableAdd( & a, 4.8, 3);

  int res = elfHashTableSearch( & a, "3.5", 3);

  if (res == -1) {
    printf("arama testi başarısız\n");
  }

  printf("arama testi başarılı indeks :%d\n", res);

}

void silme_testi() {
  printf("---------\n");
  printf("Silme testi başlatılıyor \n");
  HashTable a;

  initHashTable( & a, 5); //ilk boyut 5 verildi

  elfHashTableAdd( & a, 1.1, 3);
  elfHashTableAdd( & a, 3.5, 3);
  elfHashTableAdd( & a, 4.8, 3);

  printf("Silmeden önce:\n");

  printHashTable( & a);

  elfHashTableRemove( & a, 3.5, 3);

  printf("Sildikten sonra:\n");
  printHashTable( & a);

  if (elfHashTableSearch( & a, 3.5, 3) == -1) {
    printf("test başarılı\n");
    return;

  }

  printf("Test başarısız.Silme yapılamadı.\n");

}

int main(int argc, char * argv[]) {

  if (argc < 2) {

    standart_degerlerle_test();

    silme_testi();

    arama_testi();

    yukleme_testi();

    int_cakisma_test();

    string_cakisma_test();

    double_cakisma_test();

    bos_HashTable_test();  

    bos_string_test(); 

  } else { //bu kısım terminal parametrelerini hashler.

    // girdi metnini atar.
    char * test = argv[1];
    long size = strlen(test);
    int hash_result = elfHash(test, size);
    printf("%d\n", hash_result);

  }

  return 0;

}