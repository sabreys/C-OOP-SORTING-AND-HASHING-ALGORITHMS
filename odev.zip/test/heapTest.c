#include <stdio.h>
#include "heap.h"
#include <time.h>
/* HEAP SORT TEST PROGRAMI
 *  int,double,float,char tiplerinde siralama yapar.
 *  12.grup programlamada ozel konular dersi 2021 yaz donemi.
 * 
*/

void standart_veri_test(){
	
    int arr[] = { 15, 12, 16, 8, 7, 6 };
    int n = sizeof(arr) / sizeof(arr[0]);
    printf("Verilen dizi:\n");
    printArray(arr, n);

    heapSort(arr, n);
 
    printf("int heap sort  sonucu:\n");
    printArray(arr, n);

   printf("-------------------\n");

    double arr2[] = { 85.2, 12.1, 12.3, 5.0, 6.7, 84.1 };
    double n2 = sizeof(arr2) / sizeof(arr2[0]);
    printf("Verilen dizi:\n");
    printArray(arr2, n2);

    heapSort(arr2, n2);
 
    printf("double heap sort sonucu:\n");
    printArray(arr2, n2);
    printf("-------------------\n");

    float arr3[] = { 192.05f, 12.2f, -18.58f, 100.5f};
    float n3 = sizeof(arr3) / sizeof(arr3[0]);
    printf("Verilen dizi:\n"); 
    printArray(arr3, n3);

    heapSort(arr3, n3);
 
    printf("float heap sort sonucu:\n");
    printArray(arr3, n3);

    printf("-------------------\n");

    char arr4[] = { 'a','z','c','s' };
    printf("Verilen dizi:\n");
    char n4 = sizeof(arr4) / sizeof(arr4[0]);
    printArray(arr4,n4);

    heapSort(arr4, n4);
 
    printf("char heap sort sonucu:\n");
    printArray(arr4, n4);
}


void best_case_test(){
	printf("------------\n");

	int arr[] = { 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,};
	int n = sizeof(arr) / sizeof(arr[0]);
    
    clock_t  begin = clock();

	heapSort(arr, n);

    clock_t end = clock();
    double runtime = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;
    printf("best case runtime : %f \n", runtime );

}


void sorted_case_test(){
	printf("------------\n");

	int arr[] = { 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
	int n = sizeof(arr) / sizeof(arr[0]);
    
    clock_t  begin = clock();

	heapSort(arr, n);

    clock_t end = clock();
    double runtime = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;
    printf("sorted case runtime : %f \n", runtime );

}


void worst_case_test(){

	printf("------------\n");

	int arr[] = { 20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,};
	int n = sizeof(arr) / sizeof(arr[0]);
    
    clock_t  begin = clock();

	heapSort(arr, n);

    clock_t end = clock();
    double runtime = (double)(end - begin) * 1000.0 / CLOCKS_PER_SEC;
    printf("worst case runtime : %f \n", runtime );

}

void empty_array_test(){
    printf("------------\n");
    printf("boş array testi : \n");
	int arr[]={};
	heapSort(arr, 0);
	printArray(arr,0);

}


int main() // Ana fonksiyon
{
standart_veri_test();
best_case_test();
worst_case_test();
sorted_case_test();
empty_array_test();

}
