#include <stdio.h>

#include <stdlib.h>

#include "interval.h"

/* interval kütüphanesi test programı.
 *  int,double,float,char tiplerinde ağaç oluşturma, sıralama ve overlap tespiti fonksiyonlarını 
 *  test eder. 
 *  12.grup programlamada özel konular dersi 2021 yaz dönemi.
 *  
 */


void standart_verilerle_test(){
  node * root3 = NULL;

  char a = 'a', b = 'b', c = 'c' ,d = 'd' , s = 's' , z = 'z', x = 'x';
  root3 = insert(root3, createInterval(c,z));
  root3 = insert(root3, createInterval(a,b));
  root3 = insert(root3, createInterval(c,d));
  root3 = insert(root3, createInterval(s,z));
  root3 = insert(root3, createInterval(a,x));

  inorder(root3);

  interval temp_inter3 = createInterval(b, d);


  printf("overlap aranıyor:");
  printInterval(temp_inter3);
  checkOverLap(root3, temp_inter3);

  printf(" silme işlemi :  low u s harfi olan node \n");

  deleteInterval(root3,s);
  
  inorder(root3);
}





// farklı tiplerde ekleme yapıldığında çökme olup olmadığını test eder
void false_param_test(){
  printf("-------------------\n");
   
  printf("Yanlış tipte parametre testi başlatılıyor...\n");

  char a = 'a', b = 'b';

  //int test bölümü
  node * root = NULL;

  root = insert(root, createInterval(15, 20));
  root = insert(root, createInterval(10.0, 30.5));
  root = insert(root, createInterval(152, 202));
  root = insert(root, createInterval(a,b));
  inorder(root);
}

// aynı değer ekleme testi
void same_value_test(){
    printf("-------------------\n");
  printf("Aynı Değer testi başlıyor...\n");

   node * root = NULL;

  root = insert(root, createInterval(15, 20));
  root = insert(root, createInterval(15, 20));
  root = insert(root, createInterval(15, 20));
 

  inorder(root);


}

// olmayadan değer silme testi. 
void false_delete_test(){

  char a= 'a';
  printf("-------------------\n");
  printf("yanlış silme testi başlatılıyor...\n");
  node * root2 = NULL;
  root2 = insert(root2, createInterval( 15.0f,  20.0f));
  root2 = insert(root2, createInterval( 10.0f,  30.0f));
  root2 = insert(root2, createInterval( 17.0f,  19.0f));
  root2 = insert(root2, createInterval( 5.0f,  20.0f));
  root2 = insert(root2, createInterval( 12.0f,  15.0f));

  root2= deleteInterval(root2,66.0f);
  root2= deleteInterval(root2,a);
  root2= deleteInterval(root2,850);
  inorder(root2);


}

// pointer alan fonksiyonların null testi. 
void null_test(){
  printf("-------------------\n");
  printf("yanlış silme testi başlatılıyor...(hata ve assert verme durumunda hatalı)\n");
  inorder(NULL);
  minValue(NULL);
}





int main(void) {

  standart_verilerle_test();
  false_param_test();
  same_value_test();
  false_delete_test();
  null_test();

}