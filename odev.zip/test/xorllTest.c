#include <string.h>

#include <stdio.h>

#include <stdlib.h>

#include "xorll.h"


/* XOR LINKEDLIST kütüphanesini denemek amaçlı test programı
 * 12.grup Programlamada özel konular dersi ödevi. 2021 yaz.
 * 
 */

void standart_veri_testi() {
  // ilk veri 5
  printf("-------------------------\n");
  printf("Float İle Test\n");

  node_ll * head = init(5.17f);
  yazdirList(head);

  printf("Float İle Test\n");
  printf("Veriler Ekleniyor...\n");
  ekle( & head, 10.1f);
  ekle( & head, 35.1f);
  ekle( & head, 20.1f);

  yazdirList(head);
  // ağaçtaki Min ve max değerleri yazdır
  max(head);
  min(head);

  printf("Silme İşlemi:\n");
  delEnd( & head);
  delEnd( & head);
  yazdirList(head);
  max(head);
  min(head);

  printf("-------------------------\n");
  printf("İnteger İle Test\n");

  node_ll * head1 = init(3);
  yazdirList(head1);

  printf("Veriler Ekleniyor...\n");
  ekle( & head1, 10);
  ekle( & head1, 35);
  ekle( & head1, 20);
  yazdirList(head1);
  // ağaçtaki Min ve max değerleri yazdır
  max(head1);
  min(head1);

  printf("Silme İşlemi:\n");
  delEnd( & head1);
  delEnd( & head1);
  yazdirList(head1);
  max(head1);
  min(head1);

  printf("-------------------------\n");
  printf("Char İle Test\n");

  char a = 'a';
  char b = 'b';
  char c = 'c';
  char d = 'd';
  node_ll * head2 = init(a);
  yazdirList(head2);

  printf("Veriler Ekleniyor...\n");
  ekle( & head2, b);
  ekle( & head2, d);
  ekle( & head2, c);
  yazdirList(head2);
  // ağaçtaki Min ve max değerleri yazdır
  max(head2);
  min(head2);

  printf("Silme İşlemi:\n");
  delEnd( & head2);
  delEnd( & head2);
  yazdirList(head2);
  max(head2);
  min(head2);

  printf("-------------------------\n");
  printf("Double İle Test\n");

  node_ll * head3 = init(15.23);
  yazdirList(head3);

  printf("Veriler Ekleniyor...\n");
  ekle( & head3, 12.33);
  ekle( & head3, 776.43);
  ekle( & head3, 1.23);
  yazdirList(head3);
  // ağaçtaki Min ve max değerleri yazdır
  max(head3);
  min(head3);

  printf("Silme İşlemi:\n");
  delEnd( & head3);
  delEnd( & head3);
  yazdirList(head3);
  max(head3);
  min(head3);

  printf("Stadart veri testi tamamlandı.\n");
  printf("-------------------------\n");
}

void null_test() {
  printf("-------------------------\n");
  printf("Null check test başlıyor...\n");
  max(NULL);
  min(NULL);
  delEnd(NULL);
  init(NULL);
}

// farklı tipte veriler eklenmeye çalıştığında çökme durumunu kontrol eder
void false_type_test() {
  printf("-------------------------\n");
  printf("Farklı tipte veriler içeren nodelar ile test başlıyor...\n");
  int a = 50800;
  float b = 3244.2f;
  char c = 'c';
  double d = 120.34;

  node_ll * head = init(a);

  printf("Veriler Ekleniyor...\n");
  ekle( & head, b);
  ekle( & head, c);
  ekle( & head, d);
  yazdirList(head);
  // ağaçtaki Min ve max değerleri yazdır
  max(head);
  min(head);

  printf("Silme İşlemi:\n");
  delEnd( & head);
  delEnd( & head);
  yazdirList(head);
  max(head);
  min(head);

}

void delete_test() {
  printf("-------------------------\n");
  printf("Silme testi başlıyor...\n");

  float b = 3244.2f;

  node_ll * head = init(b);
  delEnd( & head);
  delEnd( & head);
  delEnd( & head);
  yazdirList(head);
  ekle( & head, 122);
  yazdirList(head);
  delEnd( & head);
  yazdirList(head);

}

int main() {
  standart_veri_testi();
  null_test();
  false_type_test();
  delete_test();
  return (0);
}